#include <iostream>
using namespace std;

int main() //counter 
{
    int days = 10;
    while (true) {
        days -= 1; // takes one away from days
        if (days == 0)
        {
            //time for the change
            days = 10;
        }
        
    }
    return 0;
}
