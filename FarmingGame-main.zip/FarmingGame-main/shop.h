#ifndef SHOP_H
#define SHOP_H

#include <string>
#include <vector>
using namespace std;

class Shop {   //declares class as 'Shop'
private:
	struct shopitem {  //groups together the variables of different types into one single unit
		string name;
		int price;
	};
	vector<shopitem> items;  //declares a vector named "items" that holds the items from the struct shopitem. - each item given a name and price

	
public:
	int price;
	Shop(); //constructor for the 'Shop' class
	void beginshopping();  //will display what items are being sold
	
};
#endif 
