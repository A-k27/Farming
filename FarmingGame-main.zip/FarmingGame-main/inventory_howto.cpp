

#include <iostream>
#include <vector>
#include <cctype>
#include "inventory.h"
#include "time.h"
using namespace std;

int main()
{
    Inventory inv; // you need to write this to call it 

    inv.sickles = 0; //all variables set to 0.
    inv.tomatoes = 0;
    inv.cherries = 0;
    inv.tomato_seeds = 0;
    inv.cherry_seeds= 0;
    inv.fertiliser = 0;
    inv.watering_can =0;
    inv.shovel = 0;

    inv.sickles = 100; // use this to assign a value to the variables
    cout << inv.get_sickles() << endl; // use this to output a function in the class 
    inv.new_sickles(200); // add 200 sickles to the total
    cout << inv.get_sickles() << endl; // return total sickles 
    inv.add_crops("tomatoes", 2); // add 2 tomatoes to the inventory
    cout << inv.inventory_out() << endl; // check the inventory total
    if (inv.item_seed_check("tomato") == false) //not enough seeds check
    {
        cout << "You dont have enough seeds to plant a tomato" << endl;
    }
    inv.add_seeds("tomatoes", 2); //add two seeds to the inventory
    if (inv.item_seed_check("tomato") == true) // enough seeds check
    {
        cout << "You have enough seeds to plant a tomato" << endl;
    }
    inv.add_item("shovel", 1); //add a shovel to inventory
    cout << inv.inventory_out() << endl; // check the inventory total
    inv.add_item("shovel", -1); //remove a shovel from the inventory
    cout << inv.inventory_out() << endl; // check the inventory total
    return 0;


} 