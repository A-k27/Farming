#ifndef SHOPSELL_H
#define SHOPSELL_H
#include "inventory.h"
#include "lower.h"
Inventory inv;



class Shop_Sell
{
    public:
    int salestotal = 0;
    const int tomatoprice = 100;
    const int cherryprice = 50;

    Shop_Sell()
    {
        std::cout << "..." << std::endl;
    }

    void begin_sell()
    {
        Inventory inv;
        inv.sickles = 100; // just for the sake of testing
        Shop_Sell sell;
        std::string item;
        std::string choice;
        std::cout << "This is the beginning of selling" << std::endl;
        int item_quantity;
        std::cout << "Please state which item you'd like to sell: Tomatoes, Cherries" << std::endl;
        std::cin >> item;
        item = convertToLowercase(string(item)); //convert it to lowercase
        if (item != "tomatoes" || item != "cherries")
        {
            while (item != "tomatoes" || item != "cherries")
            {
                std::cout<< "You have made an invalid selection, please try again" << std::endl;
                std::cin >> item;
                item = convertToLowercase(string(item));
                if (item == "tomatoes" || item == "cherries")
                {
                    break;
                }
            }
        }
        std::cout << item << "Sells for:" << "" << sell.price_check(item) << "" << "sickles. Would you like to continue? Y/N" <<std::endl;
        std::cin >> choice;
        choice = convertToLowercase(string(choice));
        if (choice == "y" || choice == "yes")
        {
            std::cout << "Please input the item quantity" << std::endl;
            std::cin >> item_quantity;
            std::cout << "You sold:" << "" <<  item_quantity << "" << item << "" << "for:" << "" <<sell.sellitem(item, item_quantity) << std::endl;
        }
        if (choice == "n")
        {
            while(choice == "n" || choice == "no")
            {
                std::cout << "Please state which item you'd like to sell: Tomatoes, Cherries" << std::endl;
                std::cin >> item;
                item = convertToLowercase(string(item)); //convert it to lowercase
                if (item != "tomatoes" || item != "cherries")
                {
                    while (item != "tomatoes" || item != "cherries")
                    {
                        std::cout<< "You have made an invalid selection, please try again" << std::endl;
                        std::cin >> item;
                        item = convertToLowercase(string(item));
                        if (item == "tomatoes" || item == "cherries")
                        {
                            break;
                        }
                    }
                }
                std::cout << item << "Sells for:" << "" << sell.price_check(item) << "" << "sickles. Would you like to continue? Y/N" <<std::endl;
                std::cin >> choice;
                choice = convertToLowercase(string(choice));
            }
            if (choice == "y")
            {
                std::cout << "Please input the item quantity" << std::endl;
                std::cin >> item_quantity;
                std::cout << "You sold:" << "" <<  item_quantity << "" << item << "" << "for:" << "" <<sell.sellitem(item, item_quantity) << std::endl;
            }
        }
    }


    int price_check(std::string item)
    {
        if(item == "tomatoes")
        {
            return tomatoprice;
        }
        if(item == "cherries")
        {
            return cherryprice;
        }
        return 0;
    }

    int sellitem(std::string item, int item_quantity)
    {
        if(item == "tomatoes")
        {
            if(inv.tomatoes >= 1)
            {
                salestotal = item_quantity * tomatoprice;
                inv.new_sickles(salestotal);
                return salestotal;
            }
        }
        if(item == "cherries")
        {
            if(inv.cherries >= 1)
            {
                salestotal = item_quantity * cherryprice;
                inv.new_sickles(salestotal);
                return salestotal;
            }
        }
        return 0;
    }

    
} ;

#endif