#ifndef MENU_H
#define MENU_H

#include <iostream>
#include <string>
#include <cinttypes>
#include "inventory.h"





int menu()
{ 
    //intro of the game
    std::cout << "Hello and welcome to Harvesta!\n"; 
    std::cout << "Please answer the following question in order to start the game.\n ";
    std::cout << " Would you like an explanation on how to play this game?(Y/N).\n "; //need the user to input yes or no
    std::string Answer;
    std::cin >> Answer;
    Inventory inv;


  

    if (Answer == "Y" || Answer == "y") // if users answer is yes need explanation of how the game works here
    {
        std::cout << "Harvesta is a game where users have their own farm to do multiple tasks throughout the day.\n"; // missing quotation mark (rachel)
        std::cout << "These tasks will change daily resulting on you receiving rewards if you complete them within the time limit.\n";
        std::cout << "In this game, your main goals are to build a town, look after crops and increase crop yield.\n";
        std::cout << "The currency you will be playing with is named sickles.\n";
        std::cout << "You will have access to an inventory which will have limited space and will contain your crops and tools.\n";
        std::cout << "You will be allowed to add (buy) and remove (sell) things from the inventory.\n";
        std::cout << "Once you begin the game it will become more self explanatory along the way.\n";
        std::cout << "Do you now have a better understanding of how to play the game?\n"; //question for answer2 not done yet (includes while loop)
    }
   
  
  else if (Answer == "N" || Answer == "n") //If user says they don't need an explanation.
    {
      std::cout << "A new game will now begin and you will receive 100 sickles, some tools and a few seeds\n."; 
      //code to give user 100 sickles, seeds and few tools to start the game here.
      inv.sickles = 100; //jenisha you dont need std:: infront of an integer or to put integer when changing a variable. (rachel)
      inv.tomato_seeds = 10;
      inv.cherry_seeds = 10;
      /*int inv.watering_can = 1;
      int inv.shovel = 10;*/ //these dont exist yet but ty
    }
  
  return 0;
}

#endif