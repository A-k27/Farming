#include <iostream>
#include "shop.h"
#include "inventory.h"
#include "shop_trade.h"


void trade_items(Inventory& inventory)
{
	std::string user_choice;
	std::cout << "What would you like to trade in from your inventory?" << std::endl;
	inventory.inventory_out();
	std::cout << "\nInput the name of the item you would like to trade: ";
	std::cin >> user_choice;

	if (user_choice == "tomato" && inventory.tomatoes >= 1)
	{
		inventory.tomatoes -= 1;
		inventory.shovel += 1;
		std::cout << "You have traded in 1 tomato for 1 shovel." << std::endl;
	}

	else if (user_choice == "cherry" && inventory.cherries >= 1)
	{
		inventory.cherries -= 1;
		inventory.fertiliser += 1;
		std::cout << "You have traded in 1 cherry for 1 fertiliser." << std::endl;

	}

	else if (user_choice == "shovel" && inventory.shovel >= 1)
	{
		inventory.shovel -= 1;
		inventory.watering_can += 1;
		std::cout << "You have traded in 1 shovel for a watering can." << std::endl;

	}

	else if (user_choice == "watering can" && inventory.watering_can >= 1)
	{
		inventory.watering_can -= 1;
		inventory.shovel += 1;
		std::cout << "You have traded in 1 watering can for 1 shovel." << std:: endl;

	}

	else
	{
		std::cout << "Sorry looks like you do not have this item in your inventory or it is unable to be traded in\n";

	}

}
//these are just some examples of trades
