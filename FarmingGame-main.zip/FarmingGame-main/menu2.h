#ifndef MENU2_H
#define MENU2_H

#include <iostream>
#include <string>
#include <cinttypes>
#include "inventory.h"
#include <algorithm>
using namespace std;
Inventory inv;

class interface
{
protected:
    string answer;
public:
    void get_answer() //get and set method
    {
        cout << answer << endl;
    }
    void set_answer(string ans)  //class created to do oop, includes data and function
    {
        answer = ans;
    }


};



int menu()
{
    //intro of the game
    string name;
    cout << "Enter your name: ";
    getline(cin, name);
    cout << "Hello" << name << " and welcome to Harvesta!\n";

    cout << "Please answer the following question in order to start the game.\n ";
    cout << " Would you like an explanation on how to play this game?\n "; //need the user to input yes or no
    string answer;
    cin >> answer;
  

    string yesList[5] = { "Yes", "Y", "Sure", "Yes please", "Affirmative" }; //array
    string noList[5] = { "No", "N", "Not at all", "No thank you" }; //array


    bool loop = true;


    for (int i = 0; i <= 1; i++)
    {
        if (answer == yesList[i]) //if user wnats an explanation the explanation will print.
        {
            cout << "Harvesta is a game where users have their own farm to do multiple tasks throughout the day.\n";
            cout << "These tasks will change daily resulting on you receiving rewards if you complete them within the time limit.\n";
            cout << "In this game, your main goals are to build a town, look after crops and increase crop yield starting with a few essential items we will offer you with when the game starts.\n";
            cout << "The currency you will be playing with is named sickles.\n";
            cout << "You will have access to an inventory which will have limited space and will contain your crops and tools.\n";
            cout << "You will be allowed to add (buy) and remove (sell) things from the inventory.\n";
            cout << "Once you begin the game it will become more self explanatory along the way.\n";
            cout << "Do you now have a better understanding of how to play the game?\n";

            for (int i = 0; i <= 1; i++)
            {
                if (answer == yesList[i])
                {
                    loop = false;
                }

            }
            cin >> answer; //input of users answer
            loop = true;
            continue;
        }
        if (answer == noList[i])
        {
            loop = false;
            break;
        }


    }



    int index = 5;
    while (index <= 5 && index > 0) //countdown from 5 and breaks out of loop and the game will now start.
    {
        cout << index << endl;
        index--;
    }



    cout << "A new game will now begin and you will receive 100 sickles, some tools and a few seeds\n.";
    //code to give user 100 sickles, few seeds and tools to start the game here.

    inv.sickles = 100;
    inv.tomato_seeds = 10;
    inv.cherry_seeds = 10;
    inv.watering_can = 1;
    inv.fertiliser = 4;
    inv.shovel = 1;

    return 0;
}




#endif
