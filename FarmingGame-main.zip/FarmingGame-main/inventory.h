/*
First approach using a class
*/
#ifndef INVENTORY_H
#define INVENTORY_H
#include <iostream>
#include <vector>
#include <cctype>

class Inventory
{
    public:
    int sickles; //all variables set to 0 automatically
    int tomatoes;
    int cherries;
    int tomato_seeds;
    int cherry_seeds;
    int watering_can;
    int fertiliser;
    int shovel;

    Inventory()
    {
        std::cout << "" << std::endl; // this will be output everytime you do the Inventory.inv/create an object
    }

    int inventory_out() //Display all the items in the inventory
    {
        std::cout << "Sickles quantity: " << sickles << "Tomato quantity: " << tomatoes << "Cherry quantity: " << cherries << "Tomato seed quantity: " << tomato_seeds << "Cherry seed quantity: " << cherry_seeds << "Watering can quantity:" << watering_can << "Shovel quantity:" << shovel << "Fertiliser quantity:" << fertiliser  << std::endl;
        return 0;
    }

    int new_sickles(int newsickles) // so the shop and menu can update the amount of sickles 
    {
        sickles = sickles + newsickles;
        return 0;
    }

    int get_sickles() // return the amount of sickles the user has 
    { 
        return sickles;
    }

    void add_seeds(std::string type, int amount) //add or remove seeds to the inventory
    {
        if (type == "tomatoes") //if type is equal to tomatoes
        {
            tomato_seeds = tomato_seeds + amount; //add amount of tomato seeds to existing tomato count
        }
             
         

        if (type == "cherries")
        {
            cherry_seeds = cherry_seeds + amount;
        }

    }
    


    void add_crops(std::string type, int amount) // type = tomatoes or cherries, amount = how many you want to add to the inventory, THIS DOESNT RETURN ANYTHING THATS WHY ITS VOID
    {
        if (type == "tomatoes") //if lowercase type is equal to tomatoes
        { 
            tomatoes = tomatoes + amount;
        }
        if (type == "cherries") //if lowercase type is equal to tomatoes
        {
            cherries = cherries + amount;
        }
    }

    void add_item(std::string type, int amount) //add or remove an item to the inventory (not seeds or crops)
    {
        if (type == "watering can")
        {
            watering_can = watering_can + amount;
        }
        if (type == "fertiliser")
        {
            fertiliser = fertiliser + amount;    
        }
        if (type == "shovel")
        {
            shovel = shovel + amount;
        }
    }

    bool item_seed_check(std::string type) //check if the user has enough seeds to plant
    {
        if (type == "tomato")
        {
            if (tomato_seeds >= 1) //if they have 1 or more seeds 
            {
                tomato_seeds = tomato_seeds - 1; // -1 seed which is used to plant
                return true; // yes they have enough seeds
            }
            else {
                return false;
            }
        }
        if (type == "cherries")
        {
            if (cherry_seeds >= 1)
            {
                cherry_seeds = cherry_seeds - 1;
                return true;
            }
            else {
                return false;
            }
        }
        if (type == "shovel")
        {
            if (shovel >= 1)
            {
                shovel = shovel - 1;
                return true;
            }
            else {
                return false;
            }
        }
        if (type == "fertiliser")
        {
            if (fertiliser >= 1)
            {
                fertiliser = fertiliser - 1;
                return true;
            }
            else {
                return false;
            }
        }
        if (type == "watering can")
        {
            if (watering_can >= 1)
            {
                watering_can = watering_can - 1;
                return true;
            }
            else {
                return false;
            }
        }


        return 0;
    }

} ;

#endif
