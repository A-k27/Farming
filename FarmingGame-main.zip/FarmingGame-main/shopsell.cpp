#include "shopsell.h"
#include "inventory.h"


int main()
{
    Inventory inv;
    inv.sickles = 100; // just for the sake of testing
    Shop_Sell sell;
    std::string item;
    std::string choice;
    int item_quantity;
    std::cout << "Please state which item you'd like to sell: Tomatoes, Cherries" << std::endl;
    std::cin >> item;
    std::cout << item << "Sells for:" << "" << sell.price_check(item) << "" << "sickles. Would you like to continue? Y/N" <<std::endl;
    std::cin >> choice;
    if (choice == "Y")
    {
        std::cout << "Please input the item quantity" << std::endl;
        std::cin >> item_quantity;
        std::cout << "You sold:" << "" <<  item_quantity << "" << item << "" << "for:" << "" <<sell.sellitem(item, item_quantity) << std::endl;
    }
    if (choice == "N")
    {
       while(choice == "N")
       {
        std::cout << "Please state which item you'd like to sell: Tomatoes, Cherries" << std::endl;
        std::cin >> item;
        std::cout << item << "Sells for:" << "" << sell.price_check(item) << "" << "sickles. Would you like to continue? Y/N" <<std::endl;
        std::cin >> choice;
        }
        if (choice == "Y")
        {
        std::cout << "Please input the item quantity" << std::endl;
        std::cin >> item_quantity;
        std::cout << "You sold:" << "" <<  item_quantity << "" << item << "" << "for:" << "" <<sell.sellitem(item, item_quantity) << std::endl;
        }
    }
    else {
        std::cout << "You've made an invalid selection" << std::endl;
        return 0;
    }
}


