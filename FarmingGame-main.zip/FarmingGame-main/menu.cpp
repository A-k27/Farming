#include "menu2.h"
int main()
{
    menu();
}
