#ifndef SHOP_CPP
#define SHOP_CPP
#include <iostream>
#include "shop.h"
#include <vector>
#include "inventory.h"
// inv.get_sickles(); #check how many sickles the user has 
//inv.new_sickles(200); #add 200 sickles

using namespace std; 

Shop::Shop() {   //constructor function for the 'Shop' class - initializes the 'items' vector of the shop class with list of available items.
	items = {  // contains the shopitem structs - each with name and pricde
		{"Tomato Seeds", 30},
		{"Cherry Seeds", 20},

	};
}


void Shop::beginshopping() {    //declares the function beginshopping() as a member function of the shop class
	std::cout << "Hello there! Welcome to your local Harvesta shop! Here are the available items you can purchase: \n"; //welcomes user
	for (int i = 0; i < items.size(); i++) {   //iterates through the 'items' vector to display a list of the available items in the shop
		std::cout<<i+1<<"." <<items[i].name<< "-" << items[i].price << " sickles \n";   //outputs what user has bought
	}


int choice;  //decalres variable to hold player's input
std::cout << "Enter the number of the item you want to buy (or E to exit): ";
cin >> choice;   //player can input their choice

	if (choice < 1 || choice > items.size()) {  
		cout << "Sorry looks like you have made an invalid choice.\n";  //checks if the player's input is within the range of available items.
		
	}
	else {
		Inventory inv;
		if (price <= inv.get_sickles()) 
		{//if the price is greater than or equal to the amount of sickles
		std::string choicestring; //declare string
		choicestring = choice; //convert choice into a string
		inv.add_crops(choicestring, 1); //add 1 crop to inventory

		cout << "You have purchased " << items[choice - 1].name << " for " << items[choice - 1].price << " sickles.\n";  // executes if the player's input is valid 
		int newsickles; 
		newsickles = inv.get_sickles() - items[choice - 1].price;
		inv.new_sickles(newsickles);
		}
	}
}

#endif
