#ifndef DIG_H
#define DIG_H
#include <iostream>
#include <string>
#include <vector>
#include "inventory.h"
using namespace std;
class farm
{
public:

	string ans;
	string g2 = "__";
	string g1 = "___";
	string tom_Seed = ".";
	string cherry_Seed = "*";
	string question;
	vector<string> plant_seed = { g1 + g1 + tom_Seed + g1 + g2 + g1 + g2 + g1 + g1 + g1 };
	vector<string> planted_tomS = { g1 + g1 + cherry_Seed + g1 + g2 + g1 + g2 + g1 + g1 + g1 };
	vector<string> planted_cherryS = { g1 + g1 + cherry_Seed + g1 + g2 + g1 + g2 + g1 + g1 + g1 };
	int growth = 1;
	int cherry_max = 15; // increased make to allow other function can occur for cherry
	int tom_max = 20;  // increased make to allow other function can occur for cherry
	int c_s = 0;
	int c_w = 0; // sets counter at 0
	int c_f = 0;
	int count_w()
	{
		// allows user to use watering can a number of times before removing it from inventory
		int maxw = 5;
		if (c_w == maxw)
		{
			cout << "you can no longer use this fetaliser";
			// remove from inventory
		}
		else
		{
			c_w = c_w + 1;
			return c_w;
		}
		return 0;
	}
	int count_f()
	{
		// allows user to use fertaliser anumber of times before removing it from inventory
		int maxf = 5;
		if (c_s == maxf)
		{
			cout << "you can no longer use this fetaliser";
			// remove from inventory
		}
		else
		{
			c_f= c_f + 1;
			return c_f;
		}
		return 0;
	}
	int count_s()
	{
		// allows user to use shovel anumber of times before removing it from inventory
		int maxs = 5;
		if (c_s == maxs)
		{
			cout << "you can no longer use this shovel";
			// remove from inventory
		}
		else
		{
			c_s = c_s + 1;
			return c_s;
		}
		return 0;
	}
	int shovel()
	{
		string a;
		cout << "Are you sure you would like to use you shovel: ";
		cin >> a;
		
	
			if (a == "yes")
			{
				// check if they have any shoves avavliable 
				growth = growth + 2;
				count_s(); // causes shovel to be removed after a number of uses 
				return growth;
			}
			else if (a == "no")
			{
				growth = growth + 1;
				return growth;
			}
		return growth;
	}

	int fertiliser()
	{
		
		string b;
		cout << "Are you sure you would like to use you fertaliser: ";
		cin >> b;
			if (b == "yes")
			{
				// check if available in inventory 
				growth = growth + 3;
				count_f(); // causes fertaliser to be removed after a number of uses 
				string u;
				cout << "would you also like to use a shovel: ";
				cin >> u;
				if (u == "yes")
				{
					shovel();
					return growth;
				}
				return growth;
			}
			else if (b == "no")
			{
				string	s;
				cout << "would you like to use the shovel: ";
				cin >> s;
				if (s == "yes")
				{
					shovel();
					return growth;

				}
				else
				{
					return growth;

				}
				return growth;
			}
		
		return growth;
	}
	int water()
	{
		int counter_w = 0; 
		int wmax = 4;
		string q;
		std::cout << "" << endl;
		std::cout << "would you like to water your crop: " << endl;
		cin >> q;
			if (q == "yes")
			{
				// add function to check if they have in inventory 
				growth = growth + 2;
				count_w(); // causes water to be removed after a number of uses 
				string y;
				cout << "would you also like to add fertiliser ";
				cin >> y;
				if (y == "yes")
				{
					fertiliser();
					string z;
					cout << "would you also like to use the shovel ";
					cin >> z;
					if (z == "yes")
					{
						shovel();
						return growth;
					}
					return growth;
				}
				return growth;

			}
			else if (q == "no")

			{
				string f;
				cout << "would you like to add fertiliser: ";
				cin >> f;
				if (f == "yes")
				{

					return fertiliser();
				}
				else if (f == "no")
				{
					string	s;
					cout << "would you like to use the shovel: ";
					cin >> s;
					if (s == "yes")
					{
						shovel();
						return growth;
					}
					else
					{
						return growth;

					}
					return growth;
				}

			}
			else
			{
				growth = growth + 1;
				return growth;
			}
		return growth;

	}
	int harvest_tomato()
	{
		// check if  a tomato seed is planted 
		
		if (water())
		{
			cout << growth;
			return growth;
		}

		if (growth > 1 && growth < tom_max)
		{
			// increases the plant by increasing growth counter 
			growth = growth + 1;
			return growth;
		}

		// when growth reaches max it will harvest seed and add plant to inventory
		else if (growth == tom_max)
		{
			inv.add_crops("tomatoes", 1);// add tomato to inventory 
		}
		return 0;

	}
	int harvest_cherry()
	{
		// check if  a tomato seed is planted 

		if (water())
		{
			cout << growth;
			return growth;
		}

		if (growth > 1 && growth <cherry_max)
		{
			// increases the plant by increasing growth counter 
			growth = growth + 1;
			return growth;
		}

		// when growth reaches max it will harvest seed and add plant to inventory
		else if (growth == cherry_max)
		{
			inv.add_crops("cherries", 1); // add cherry to inventory 
		}
		return 0;
	}
	void dig(string question)
	{
		
		// lets user know they are now able to select seed to plant by calling answer function which will gives then options
		question = "Now you are able to select the seed you will plant";
		std::cout << question << endl;
		answer();

	}

	vector<string> no_seed()
	{
		// returns empty ground with no seeds planted 
		plant_seed = { g1 , g1 , g2 , g1 , g2 , g1 , g2 , g1 };
		for (int l = 0; l < plant_seed.size(); l++)
		{
			std::cout << plant_seed[l];

		}
		return plant_seed;
	}

	vector<string> tomato()
	{
		//plants tomato seed 
		// increases growth counter by 1 for harvest function 
		plant_seed = { g1 , g1 , tom_Seed , g1 , g2 , g1 };
		planted_tomS = plant_seed;
		for (int i = 0; i < planted_tomS.size(); i++)
		{
			std::cout << planted_tomS[i];
			growth = growth + 1;
		}
		harvest_tomato();
		return plant_seed;
		
	}

	vector<string>cherry()
	{
		// plants cherry seed 
		// increases growth counter by 1 for harvest function
		plant_seed = { g1 , g1 , cherry_Seed , g1 , g2 , g1 };
		planted_cherryS = plant_seed;
		for (int j = 0; j < planted_cherryS.size(); j++)
		{
			std::cout << planted_cherryS[j];
			growth = growth + 1;
		}
		harvest_cherry();
		return planted_cherryS;
		

	}

	vector<std::string>answer()
	{
		// ask user which seeds they would like to plant 

		std::cout << "which seed would you like to plant?" << endl;
		std::cout << "enter tomato if you would like to grow a tomato. enter cherry if you would like to grow a cherry tree." << endl;
		std::cin >> ans;
		{
			// if user answers with tomato plants tomato seed by using tomato function
			if (ans == "tomato" || ans == "Tomato" || ans == "TOMATO")
			{
				return tomato();
			}
			// if user answers with tomato plants cherry seed by using cherry function
			if (ans == "cherry" || ans == "Cherry" || ans == "CHERRY")
			{
				return cherry();

			}
			// if user enetrs anything pther then the 2 options available it outputs the ground with no seeds planted 
			else {
				cout << "you did not pick from the options";
				return no_seed();
			}
		}
	}

};



#endif