#ifndef LOWER_H
#define LOWER_H
#include <iostream>
#include <sstream>
//used to convert a string to lowercase
using namespace std;
string convertToLowercase(string word)
{
    // stringstream (<sstream>) cout but into a variable.
    stringstream out;

    for(size_t i = 0; i < word.length(); i++) //iterate through each character in list 
    {
        char c = word.c_str()[i];
        out << char(tolower(c));
    }

    return out.str(); //return string
}

/*int main(int argc, char* argv[])
{
    if (argc < 2)
        cout << convertToLowercase(string("ExAmPlE sTrInG"));
    else 
        cout << convertToLowercase(string(argv[1]));
    
    return 0;
} */ 

#endif