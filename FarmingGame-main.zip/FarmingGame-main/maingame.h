
#ifndef MAINGAME_H
#define MAINGAME_H
#include <iostream>
#include "shop.h"
#include "dig.h"
#include "menu2.h"
#include "shop.cpp"
#include "shopsell.h"
#include "lower.h"

int main_game()

{

	std::cout << "Would you like to shop or farm (farm/shop).\n "; //need the user to input farm or shop
	std::string Answer;
	std::cin >> Answer;
	Answer = convertToLowercase(string(Answer)); //convert stuff to lowercase


	

	if (Answer == "farm") 
	{
		farm digg;
		string question;
		digg.dig(question);
	}
	if (Answer == "shop") 
	{
		std::cout << "Would you like to buy or sell?" << std::endl;
		std::cin >> Answer;
		convertToLowercase(string(Answer));
		if (Answer == "buy")
		{
			Shop harvestaShop; //creates object of the shop class names 'harvestaShop'
			harvestaShop.beginshopping(); //calls beginshopping function

		}
		if (Answer == "sell")
		{
			Shop_Sell shop;
			shop.begin_sell();
		}
	} 
	return 0;
}
#endif
