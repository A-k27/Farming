#include <iostream>
#include <string>
#include "menu2.h"
int main()
{
    menu();
    
}
