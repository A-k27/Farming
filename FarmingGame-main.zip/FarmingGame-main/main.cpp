#include <iostream>
#include "menu2.h"
#include "maingame.h"


using namespace std;

int main() 
{
	// THE MAIN HAS BEEN MOVED TO MAINGAME.H
	menu();
	int n=0; // THIS IS TEMPORARY, REPLACE THIS WITH THE TURN COUNTER
	while (n<10)
	{
		std::cout << "day: " << n << std::endl; // TEMP: SAY WHAT DAY IT IS
		main_game();
		n = n + 1; // TEMP: ADD ONE TO COUNTER
	}
	
	return 0;
	
}
