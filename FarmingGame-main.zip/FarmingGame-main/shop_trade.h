#ifndef SHOP_TRADE_H
#define SHOP_TRADE_H	
#include "inventory.h"
#include "shop.h"

class Trade {
public:
	void trade_items(Inventory& inventory);// arguments passed by reference
};
#endif
